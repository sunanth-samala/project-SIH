<?php
$photo = $_post['image'];
$first_name = $_post['firstname'];
$last_name = $_post['lastname'];
$user_name = $_post['username'];
$email = $_post['email'];
$password = $_post['password'];
$mobile_no = $_post['mobile'];
$pan_card = $_post['pancard'];
$adhar_card = $_post['adhar'];

$host = "";
$bdpassword ="";
$dbusername ="";
$dbname = "";

$conn = new mysqli( $host, $dbusername, $bdpassword, $dbname);
if(mysqli_connection_error()){
die('connect Error('.mysqli_connection_error().')' . mysqli_connection_error());
} else {
    $SELECT ="SELECT email From form1 where email = ? limit 1";
    $INSERT ="INSERT Into form1 (photo,first_name,last_name,user_name,email,password,mobile_no,pan_card,adhar_card) values (?,?,?,?,?,?,?,?,?) ";

    $stmt = $conn->prepar($SELECT);
    $stmt -> $bind_param("$",$email);
    $stmt -> execute();
    $stmt -> bind_result($email);
    $stmt -> store_result();
    $rnum = $stmt -> num_rows;
    
    if($rnum==0){
        $stmt-> close():

        $stmt = $conn->prepare($INSERT);
        $stmt->bind_param(".sssssisi",$photo,$first_name,$last_name,$user_name,$email,$password,$mobile_no,$pan_card,$adhar_card);
        $stmt->execute();
    } else {
        echo "email alreasy exists";
    }

}
}

?>